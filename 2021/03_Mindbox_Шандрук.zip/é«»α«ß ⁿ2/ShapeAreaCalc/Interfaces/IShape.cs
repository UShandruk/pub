﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalc.Interfaces
{
    public interface IShape
    {
        /// <summary>
        /// Вычислить площадь
        /// </summary>
        /// <returns>Площадь</returns>
        double GetArea();
    }
}
