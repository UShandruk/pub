﻿using System;

namespace ShapeAreaCalc
{
    public class Calculator
    {
    }
}
