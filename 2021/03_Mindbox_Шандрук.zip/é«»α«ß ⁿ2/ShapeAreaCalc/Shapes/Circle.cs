﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalc.Shapes
{
    /// <summary>
    /// Круг
    /// </summary>
    public class Circle : Interfaces.IShape
    {
        public double Radius { get; set; }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="radius">Радиус</param>
        public Circle(double radius)
        {
            Radius = radius;
        }

        /// <summary>
        /// Вычислить площадь
        /// </summary>
        /// <returns>Площадь</returns>
        public double GetArea()
        {
            double area = Math.PI * Radius * Radius;
            return area;
        }
    }
}
