﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalc.Shapes
{
    /// <summary>
    /// Треугольник
    /// </summary>
    public class Triangle : Interfaces.IShape
    {
        public double Side1 { get; set; }
        public double Side2 { get; set; }
        public double Side3 { get; set; }

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="side1">Сторона 1</param>
        /// <param name="side2">Сторона 2</param>
        /// <param name="side3">Сторона 3</param>
        public Triangle(double side1, double side2, double side3)
        {
            Side1 = side1;
            Side2 = side2;
            Side3 = side3;
        }

        /// <summary>
        /// Является ли треугольник прямоугольным (по теореме Пифагора)
        /// </summary>
        /// <returns>true - прямоугольный, false - нет</returns>
        public bool IsRightTriangle()
        {
            List<double> sides = new List<double> { Side1, Side2, Side3 };
            sides.OrderBy(x => x);
            double a = sides[0];
            double b = sides[1];
            double c = sides[2];
            bool isRightTriangle = (c * c == (a * a + b * b));
            return isRightTriangle;
        }

        /// <summary>
        /// Вычислить площадь (по формуле Герона)
        /// </summary>
        /// <returns>Площадь</returns>
        public double GetArea()
        {
            double area;
            double halfP = (Side1 + Side2 + Side3) / 2;
            double tmp = halfP * (halfP - Side1) * (halfP - Side2) * (halfP - Side3);
            if(tmp > 0)
                area = Math.Sqrt(tmp);
            else
                area = 0;
            return area;
        }
    }
}
