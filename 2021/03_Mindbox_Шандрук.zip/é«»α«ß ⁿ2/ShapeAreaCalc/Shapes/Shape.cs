﻿using ShapeAreaCalc.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalc.Shapes
{
    /// <summary>
    /// Неизвестная фигура
    /// </summary>
    public class Shape : IShape
    {
        IShape shape { get; set; }



        /// <summary>
        /// Конструктор
        /// </summary>
        public Shape(IShape figure)
        {
            shape = figure;
        }

        ///// <summary>
        ///// Вычислить площадь
        ///// </summary>
        ///// <returns>Площадь</returns>
        public double GetArea() => shape.GetArea();
    }
}
