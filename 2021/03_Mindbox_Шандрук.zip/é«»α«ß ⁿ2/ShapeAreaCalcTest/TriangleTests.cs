﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalcTest
{
    public class TriangleTests
    {
        [TestCase]
        public void Triangle_GetArea()
        {
            //arrange
            double expectedArea = 6;
            ShapeAreaCalc.Shapes.Triangle triangle = new ShapeAreaCalc.Shapes.Triangle(3, 4, 5);

            //act
            double area = triangle.GetArea();

            //assert
            Assert.AreEqual(expectedArea, area);
        }

        [TestCase]
        public void Triangle_GetArea_Impossible()
        {
            //arrange
            double expectedArea = 0;
            ShapeAreaCalc.Shapes.Triangle triangle = new ShapeAreaCalc.Shapes.Triangle(3, 1, 5);

            //act
            double area = triangle.GetArea();

            //assert
            Assert.AreEqual(expectedArea, area);
        }

        [TestCase]
        public void Triangle_GetArea_Zero()
        {
            //arrange
            double expectedArea = 0;
            ShapeAreaCalc.Shapes.Triangle triangle = new ShapeAreaCalc.Shapes.Triangle(3, 0, 5);

            //act
            double area = triangle.GetArea();

            //assert
            Assert.AreEqual(expectedArea, area);
        }

        [TestCase]
        public void Triangle_GetArea_Negative()
        {
            //arrange
            double expectedArea = 6;
            ShapeAreaCalc.Shapes.Triangle triangle = new ShapeAreaCalc.Shapes.Triangle(3, 4, 5);

            //act
            double area = triangle.GetArea();

            //assert
            Assert.AreEqual(expectedArea, area);
        }

        [TestCase]
        public void Triangle_IsRight_True()
        {
            //arrange
            ShapeAreaCalc.Shapes.Triangle triangle = new ShapeAreaCalc.Shapes.Triangle(3, 4, 5);

            //act
            bool isRight = triangle.IsRightTriangle();

            //assert
            Assert.IsTrue(isRight);
        }

        [TestCase]
        public void Triangle_IsRight_False()
        {
            //arrange
            ShapeAreaCalc.Shapes.Triangle triangle = new ShapeAreaCalc.Shapes.Triangle(3, 4, 5);

            //act
            bool isRight = triangle.IsRightTriangle();

            //assert
            Assert.IsTrue(isRight);
        }

        [TestCase]
        public void Triangle_IsRight_False_Zero()
        {
            //arrange
            ShapeAreaCalc.Shapes.Triangle triangle = new ShapeAreaCalc.Shapes.Triangle(3, 0, 5);

            //act
            bool isRight = triangle.IsRightTriangle();

            //assert
            Assert.IsFalse(isRight);
        }

        [TestCase]
        public void Triangle_IsRight_False_Negative()
        {
            //arrange
            ShapeAreaCalc.Shapes.Triangle triangle = new ShapeAreaCalc.Shapes.Triangle(3, -4, 5);

            //act
            bool isRight = triangle.IsRightTriangle();

            //assert
            Assert.IsTrue(isRight);
        }
    }
}
