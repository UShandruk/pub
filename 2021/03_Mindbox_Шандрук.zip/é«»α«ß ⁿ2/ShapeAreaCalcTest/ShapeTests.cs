using NUnit.Framework;
using System;

namespace ShapeAreaCalcTest
{
    
    public class ShapeTests
    {
        [TestCase]
        public void Shape_GetArea_Circle()
        {
            //arrange
            ShapeAreaCalc.Shapes.Circle circle = new ShapeAreaCalc.Shapes.Circle(6);
            ShapeAreaCalc.Shapes.Shape shape = new ShapeAreaCalc.Shapes.Shape(circle);
            double expectedArea = circle.GetArea();

            //act
            double shapeArea = shape.GetArea();
            

            //assert
            Assert.AreEqual(shapeArea, expectedArea);
        }

        [TestCase]
        public void Shape_GetArea_Triangle()
        {
            //arrange
            ShapeAreaCalc.Shapes.Triangle triangle = new ShapeAreaCalc.Shapes.Triangle(3, 2, 5);
            ShapeAreaCalc.Shapes.Shape shape = new ShapeAreaCalc.Shapes.Shape(triangle);

            //act            
            double expectedArea = triangle.GetArea();
            double shapeArea = shape.GetArea();

            //assert
            Assert.AreEqual(shapeArea, expectedArea);
        }
    }
}