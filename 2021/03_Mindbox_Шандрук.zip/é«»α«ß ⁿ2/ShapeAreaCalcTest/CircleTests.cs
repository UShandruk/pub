﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeAreaCalcTest
{
    public class CircleTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [TestCase]
        public void Circle_GetArea()
        {
            //arrange
            double radius = 6;
            ShapeAreaCalc.Shapes.Circle circle = new ShapeAreaCalc.Shapes.Circle(radius);
            double expectedArea = Math.PI * radius * radius;

            //act
            double area = circle.GetArea();

            //assert
            Assert.AreEqual(expectedArea, area);
        }

        [TestCase]
        public void Circle_GetArea_Zero()
        {
            //arrange
            double radius = 0;
            ShapeAreaCalc.Shapes.Circle circle = new ShapeAreaCalc.Shapes.Circle(radius);
            double expectedArea = Math.PI * radius * radius;

            //act
            double area = circle.GetArea();

            //assert
            Assert.AreEqual(expectedArea, area);
        }

        [TestCase]
        public void Circle_GetArea_Negative()
        {
            //arrange
            double radius = -6;
            ShapeAreaCalc.Shapes.Circle circle = new ShapeAreaCalc.Shapes.Circle(radius);
            double expectedArea = Math.PI * radius * radius;

            //act
            double area = circle.GetArea();

            //assert
            Assert.AreEqual(expectedArea, area);
        }
    }
}
